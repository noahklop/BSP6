package lu.uni.javaee.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaeeSpringbootRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                JavaeeSpringbootRestApplication.class, args);
    }

}

