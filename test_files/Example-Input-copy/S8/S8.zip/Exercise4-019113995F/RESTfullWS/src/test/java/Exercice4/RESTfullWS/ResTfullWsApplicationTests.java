package Exercice4.RESTfullWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTfullWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
