Lucas Villiere 019113995F

This application use MAVEN and spring-boot to run the project.

You can run the project with the command "mvn spring-boot:run" in the root folder of the project.

If you need more information you can use the openAPI documentation by going to this link: http://localhost:8080/exercise4/api.

This application has a Get method and takes as body request a country or a ISO2 code.

Please use an application like Postman to test the application.

The application will return a JSON with the country deaths and covid test.