package com.uni.exercise4;

public class BadResponseItem {
    private String Error;

    public BadResponseItem() {
    }

    public String getError() {
        return Error;
    }

    public void setError(String Error) {
        this.Error = Error;
    }
}
