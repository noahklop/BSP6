package com.uni.exercise4;

public class ResponseItem {
    private int cases;
    private int deaths;

    public ResponseItem() {
    }

    public int getCases() {
        return cases;
    }

    public void setCases(int cases) {
        this.cases = cases;
    }

    public int getDeaths() {
        return deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }
}
